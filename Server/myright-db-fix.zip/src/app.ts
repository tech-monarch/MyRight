import express from "express";
import helmet from "helmet";
import cors from "cors";
import cookieParser from "cookie-parser";
import pinoHttp from "pino-http";
import { randomUUID } from "crypto";
import { env } from "@/config/env";
import { authRouter } from "@/modules/auth/auth.routes";
import { disputesRouter } from "@/modules/disputes/disputes.routes";
import { adminRouter } from "@/modules/admin/admin.routes";
import { mediationRouter } from "@/modules/mediation/mediation.routes";
import { publicSigningRouter } from "@/modules/resolution/public-signing.routes";
import { whatsappRouter } from "@/modules/admin/whatsapp.routes";
import { whatsAppProvider } from "@/infrastructure/notifications/whatsapp.provider";
import { errorHandler, notFoundHandler } from "@/middleware/errorHandler";
import { apiRateLimiter } from "@/middleware/rateLimit";
import { prisma } from "@/infrastructure/database/prisma";

const app = express();

// Render (and most PaaS hosts) sit the app behind a reverse proxy, which
// sets X-Forwarded-For to the real client IP. Without this, req.ip
// resolves to the proxy's own address for every request, and
// express-rate-limit refuses to trust the header at all (see the
// ERR_ERL_UNEXPECTED_X_FORWARDED_FOR warning this fixes). `1` means
// trust exactly one hop, Render's own edge proxy, not an arbitrary chain
// an attacker could spoof by adding their own X-Forwarded-For header.
app.set("trust proxy", 1);

// Request ID + structured logging first, so every later log line (and the
// error handler) can be tied back to one request.
app.use(
  pinoHttp({
    genReqId: (req) => req.headers["x-request-id"]?.toString() ?? randomUUID(),
    redact: ["req.headers.cookie", "req.headers.authorization"],
  })
);

app.use(helmet());
app.use(
  cors({
    origin: env.CLIENT_ORIGIN,
    credentials: true, // required for the browser to send/receive the session cookie
  })
);
app.use(express.json({ limit: "1mb" }));
app.use(cookieParser());
app.use(apiRateLimiter);

app.get("/health", (_req, res) => res.json({ status: "ok" }));
app.get("/health/db", async (_req, res) => {
  const { prisma } = await import("@/infrastructure/database/prisma.js");
  try {
    await prisma.$queryRaw`SELECT 1`;
    res.json({ status: "ok" });
  } catch {
    res.status(503).json({ status: "unavailable" });
  }
});

app.use("/api/auth", authRouter);
app.use("/api/disputes", disputesRouter);
app.use("/api/admin", adminRouter);
app.use("/api/admin/whatsapp", whatsappRouter);
app.use("/api/mediation", mediationRouter);
app.use("/api/sign", publicSigningRouter);

app.use(notFoundHandler);
app.use(errorHandler);

const server = app.listen(env.PORT, () => {
  console.log(`MyRight API listening on port ${env.PORT} (${env.NODE_ENV})`);
});

// Render sends SIGTERM on deploy/restart. Stop accepting requests, let
// in-flight ones finish, then close the Prisma pool once (not per request).
let shuttingDown = false;
function shutdown(signal: string) {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log(`${signal} received, shutting down`);
  const forceExit = setTimeout(() => process.exit(1), 10_000);
  forceExit.unref();
  server.close(() => {
    prisma
      .$disconnect()
      .catch(() => undefined)
      .finally(() => process.exit(0));
  });
  server.closeIdleConnections?.();
}
process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));

// Reconnects using the saved auth state on disk if this courthouse's
// WhatsApp number was already linked in a previous run, does nothing
// (stays "disabled") if WHATSAPP_ENABLED is false.
void whatsAppProvider.start();

export { app };
